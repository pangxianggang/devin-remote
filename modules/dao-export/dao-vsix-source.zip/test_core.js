/* Standalone test of api + exporter + zip without VS Code. */
const api = require('./out/api');
const { exportSessionToZip } = require('./out/exporter');
const fs = require('fs');

(async () => {
  console.log('1. Login...');
  const auth = await api.login(process.argv[2], process.argv[3]);
  console.log('   token:', auth.token.slice(0, 20) + '...', '| org:', auth.orgName, auth.orgId);

  console.log('2. List sessions...');
  const sessions = await api.listSessions(auth);
  console.log('   sessions:', sessions.length);
  console.log('   first 3:', sessions.slice(0, 3).map(s => `${s.devin_id} | ${(s.title||'').slice(0,40)} | ${s.status||s.status_enum||''}`));

  // Pick a small-ish session
  const target = sessions[Math.min(2, sessions.length - 1)];
  console.log('3. Session info for', target.devin_id);
  const info = await api.getSessionInfo(auth, target.devin_id);
  console.log('   title:', info.title, '| status:', info.status || info.status_enum);

  console.log('4. Event stream...');
  const events = await api.getEventStream(auth, target.devin_id);
  console.log('   events:', events.length, '| types:', [...new Set(events.map(e=>e.type))].slice(0,10).join(','));

  console.log('5. Export to ZIP...');
  const zip = await exportSessionToZip(auth, target.devin_id, target.title || target.devin_id,
    (m) => process.stdout.write('   > ' + m + '\n'));
  fs.writeFileSync('test_export.zip', zip);
  console.log('   ZIP size:', (zip.length/1024).toFixed(1), 'KB → test_export.zip');
  console.log('ALL TESTS PASSED');
})().catch(e => { console.error('FAILED:', e); process.exit(1); });
