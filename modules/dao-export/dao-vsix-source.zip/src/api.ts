/**
 * Devin API Client — 道法自然
 * Handles auth, session listing, event streaming, file resolution.
 */
import * as https from 'https';
import * as http from 'http';

const LOGIN_URL = 'https://windsurf.com/_devin-auth/password/login';
const API_BASE = 'https://app.devin.ai/api';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';

export interface AuthState {
  token: string;
  orgId: string;
  orgBare: string;
  orgName: string;
  email: string;
}

export interface SessionInfo {
  devin_id: string;
  title: string;
  status: string;
  created_at: string;
  updated_at: string;
  activity_status?: string;
  current_activity?: string;
  tags?: string[];
  pull_requests?: any[];
  [key: string]: any;
}

export interface EventItem {
  event_id?: string;
  type: string;
  timestamp?: string;
  created_at_ms?: number;
  message?: string;
  file_updates?: FileUpdate[];
  [key: string]: any;
}

export interface FileUpdate {
  file_path: string;
  contents_key?: string;
  action_type?: string;
}

function request(url: string, options: {
  method?: string;
  headers?: Record<string, string>;
  body?: string;
  timeout?: number;
}): Promise<{ status: number; body: string }> {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const mod = parsed.protocol === 'https:' ? https : http;
    const reqOptions = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: options.method || 'GET',
      headers: options.headers || {},
      timeout: options.timeout || 30000,
      rejectUnauthorized: false,
    };

    const req = mod.request(reqOptions, (res) => {
      const chunks: Buffer[] = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => {
        resolve({ status: res.statusCode || 0, body: Buffer.concat(chunks).toString('utf-8') });
      });
    });

    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });

    if (options.body) {
      req.write(options.body);
    }
    req.end();
  });
}

export async function login(email: string, password: string): Promise<AuthState> {
  const resp = await request(LOGIN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'User-Agent': UA },
    body: JSON.stringify({ email, password }),
  });

  if (resp.status !== 200) {
    throw new Error(`Login failed (${resp.status}): ${resp.body.slice(0, 200)}`);
  }

  const data = JSON.parse(resp.body);
  const token = data.token || data.access_token;
  if (!token) {
    throw new Error(`No token in response: ${JSON.stringify(data).slice(0, 200)}`);
  }

  // Get org info
  const orgResp = await request(`${API_BASE}/users/post-auth`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'User-Agent': UA,
    },
    body: '{}',
  });

  const orgData = JSON.parse(orgResp.body);
  const orgId = orgData.org_id || orgData.orgId;
  const orgBare = orgId?.replace('org-', '') || '';
  const orgName = orgData.org_name || orgData.orgName || '';

  return { token, orgId, orgBare, orgName, email };
}

function authHeaders(auth: AuthState, extra?: Record<string, string>): Record<string, string> {
  return {
    'Authorization': `Bearer ${auth.token}`,
    'x-cog-org-id': auth.orgId,
    'User-Agent': UA,
    'Accept': 'application/json',
    ...extra,
  };
}

export async function listSessions(auth: AuthState): Promise<SessionInfo[]> {
  const url = `${API_BASE}/org-${auth.orgBare}/v2sessions`;
  const resp = await request(url, {
    headers: authHeaders(auth),
    timeout: 60000,
  });

  if (resp.status !== 200) {
    throw new Error(`List sessions failed (${resp.status})`);
  }

  const data = JSON.parse(resp.body);
  return data.result || data.sessions || data.data || [];
}

export async function getSessionInfo(auth: AuthState, devinId: string): Promise<SessionInfo> {
  const url = `${API_BASE}/sessions/${devinId}`;
  const resp = await request(url, { headers: authHeaders(auth) });
  return JSON.parse(resp.body);
}

export async function getEventStream(auth: AuthState, devinId: string): Promise<EventItem[]> {
  const url = `${API_BASE}/events/${devinId}/stream`;
  const resp = await request(url, {
    headers: { ...authHeaders(auth), 'Accept': 'text/event-stream' },
    timeout: 180000,
  });

  // Parse SSE/ndjson stream
  const merged = new Map<string, EventItem>();
  const raw = resp.body;

  // Try JSON objects
  let i = 0;
  while (i < raw.length) {
    while (i < raw.length && ' \r\n\t'.includes(raw[i])) { i++; }
    if (i >= raw.length) { break; }

    // Try to find a JSON object
    if (raw[i] === '{') {
      let depth = 0;
      let j = i;
      let inStr = false;
      let escaped = false;
      for (; j < raw.length; j++) {
        if (escaped) { escaped = false; continue; }
        if (raw[j] === '\\' && inStr) { escaped = true; continue; }
        if (raw[j] === '"') { inStr = !inStr; continue; }
        if (inStr) { continue; }
        if (raw[j] === '{') { depth++; }
        if (raw[j] === '}') { depth--; if (depth === 0) { j++; break; } }
      }

      try {
        const obj = JSON.parse(raw.slice(i, j));
        if (obj.result && Array.isArray(obj.result)) {
          for (const ev of obj.result) {
            const eid = ev.event_id || `${ev.type}-${ev.timestamp}-${ev.created_at_ms}`;
            if (!merged.has(eid)) { merged.set(eid, ev); }
          }
        } else if (obj.type) {
          const eid = obj.event_id || `${obj.type}-${obj.timestamp}`;
          if (!merged.has(eid)) { merged.set(eid, obj); }
        }
      } catch { /* skip malformed */ }
      i = j;
    } else {
      // SSE line: data: {...}
      const lineEnd = raw.indexOf('\n', i);
      const end = lineEnd === -1 ? raw.length : lineEnd;
      const line = raw.slice(i, end).trim();
      i = end + 1;

      if (line.startsWith('data:')) {
        const dataStr = line.slice(5).trim();
        if (dataStr && dataStr !== '[DONE]') {
          try {
            const obj = JSON.parse(dataStr);
            if (obj.result && Array.isArray(obj.result)) {
              for (const ev of obj.result) {
                const eid = ev.event_id || `${ev.type}-${ev.timestamp}`;
                if (!merged.has(eid)) { merged.set(eid, ev); }
              }
            } else if (obj.type) {
              const eid = obj.event_id || `${obj.type}-${obj.timestamp}`;
              if (!merged.has(eid)) { merged.set(eid, obj); }
            }
          } catch { /* skip */ }
        }
      }
    }
  }

  const events = Array.from(merged.values());
  events.sort((a, b) => (a.created_at_ms || 0) - (b.created_at_ms || 0));
  return events;
}

export async function getFirstLoad(auth: AuthState, devinId: string): Promise<EventItem[]> {
  const url = `${API_BASE}/events/first-load/${devinId}`;
  const resp = await request(url, { headers: authHeaders(auth) });
  const data = JSON.parse(resp.body);
  return data.result || data.events || [];
}

export async function resolvePresignedUrls(
  auth: AuthState, devinId: string, keys: string[]
): Promise<Map<string, { url: string; headers: Record<string, string> }>> {
  const result = new Map<string, { url: string; headers: Record<string, string> }>();
  const CHUNK = 40;

  const batches: string[][] = [];
  for (let i = 0; i < keys.length; i += CHUNK) {
    batches.push(keys.slice(i, i + CHUNK));
  }

  const url = `${API_BASE}/presigned-url/batch/${devinId}`;
  const resolveBatch = async (batch: string[]) => {
    const resp = await request(url, {
      method: 'POST',
      headers: { ...authHeaders(auth), 'Content-Type': 'application/json' },
      body: JSON.stringify({ s3_key_list: batch }),
      timeout: 30000,
    });
    try {
      const data = JSON.parse(resp.body);
      const urls = data.urls_list || [];
      const hdrs = data.headers_list || [];
      for (let j = 0; j < batch.length; j++) {
        if (urls[j]) {
          result.set(batch[j], { url: urls[j], headers: hdrs[j] || {} });
        }
      }
    } catch { /* skip batch */ }
  };

  await runPool(batches, 6, resolveBatch);
  return result;
}

/** Run async tasks over items with bounded concurrency. */
export async function runPool<T>(
  items: T[], concurrency: number, worker: (item: T) => Promise<void>
): Promise<void> {
  let next = 0;
  const lanes = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (next < items.length) {
      const i = next++;
      await worker(items[i]);
    }
  });
  await Promise.all(lanes);
}

export async function downloadFileWithRetry(
  url: string, headers?: Record<string, string>, retries = 3
): Promise<Buffer> {
  let lastErr: unknown;
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      return await downloadFile(url, headers);
    } catch (e) {
      lastErr = e;
      if (attempt < retries - 1) {
        await new Promise((r) => setTimeout(r, 1500 * (attempt + 1)));
      }
    }
  }
  throw lastErr;
}

export async function downloadFile(url: string, headers?: Record<string, string>): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const mod = parsed.protocol === 'https:' ? https : http;
    const req = mod.request({
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: 'GET',
      headers: headers || {},
      timeout: 45000,
      rejectUnauthorized: false,
    }, (res) => {
      const chunks: Buffer[] = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.end();
  });
}

export function extractAllKeys(events: EventItem[]): string[] {
  const keys = new Set<string>();
  function walk(obj: any) {
    if (!obj || typeof obj !== 'object') { return; }
    if (Array.isArray(obj)) { obj.forEach(walk); return; }
    for (const [k, v] of Object.entries(obj)) {
      if (k === 'contents_key' && typeof v === 'string' && v) {
        keys.add(v);
      } else {
        walk(v);
      }
    }
  }
  walk(events);
  return Array.from(keys).sort();
}

// Account-level data
export async function getPlaybooks(auth: AuthState): Promise<any[]> {
  const resp = await request(`${API_BASE}/org-${auth.orgBare}/playbooks`, {
    headers: authHeaders(auth),
  });
  return JSON.parse(resp.body);
}

export async function getKnowledge(auth: AuthState): Promise<any> {
  const resp = await request(`${API_BASE}/org-${auth.orgBare}/learning/all`, {
    headers: authHeaders(auth),
  });
  return JSON.parse(resp.body);
}

export async function getSecrets(auth: AuthState): Promise<any[]> {
  const resp = await request(`${API_BASE}/org-${auth.orgBare}/secrets`, {
    headers: authHeaders(auth),
  });
  return JSON.parse(resp.body);
}

export async function getOrgSettings(auth: AuthState): Promise<any> {
  const resp = await request(`${API_BASE}/organizations/${auth.orgId}`, {
    headers: authHeaders(auth),
  });
  return JSON.parse(resp.body);
}
